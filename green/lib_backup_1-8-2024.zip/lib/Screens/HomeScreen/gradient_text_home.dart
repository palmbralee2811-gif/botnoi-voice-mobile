// import 'dart:ffi';

import 'package:flutter/material.dart';

class GradientTextHome extends StatelessWidget {
  final String text;

  final TextStyle style;
  final Gradient gradient;

  GradientTextHome({
    required this.text,
    required this.style,
    required this.gradient,
  });

  @override
  Widget build(BuildContext context) {
    return ShaderMask(
      shaderCallback: (bounds) {
        return gradient
            .createShader(Rect.fromLTWH(0, 0, bounds.width, bounds.height));
      },
      child: Text(
        text,
        style: style.copyWith(color: Colors.white), // text color จะไม่ถูกใช้
      ),
    );
  }
}
